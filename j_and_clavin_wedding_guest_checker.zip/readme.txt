INSTRUCTIONS:

1. Open 'index.html' to test the guest checker site.
2. Open 'admin.html' locally to see logs of names entered.
3. Edit 'guests.js' to change the guest list and table/chair assignments.
4. Upload 'index.html' and 'guests.js' to GitHub for your public site.
5. Keep 'admin.html' private for your own use.

NOTE: This uses localStorage so logs are saved only on your device unless you implement a backend.