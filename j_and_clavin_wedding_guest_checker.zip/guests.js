const guests = [
  { name: "Juan Dela Cruz", table: "1", chair: "A" },
  { name: "Maria Santos", table: "1", chair: "B" },
  { name: "Pedro Reyes", table: "2", chair: "A" },
  { name: "Anna Lopez", table: "2", chair: "B" }
];